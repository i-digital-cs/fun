export type Locale = "en" | "ar";

export interface CategoryItem {
  id: string;
  emoji: string;
  count: number;
}

export type Urgency = "almostFull" | "fillingFast" | "new" | "popular";

export interface EventItem {
  id: string;
  img: string;
  emoji: string;
  joined: number;
  total: number;
  hostInitials: string;
  urgency: Urgency;
  copy: {
    category: string;
    title: string;
    venue: string;
    date: string;
    price: string;
    host: string;
  };
}

const en = {
  brand: "Community Platform",
  navHome: "Home",
  navNearby: "Nearby",
  navMy: "My Events",
  navChat: "Chat",
  searchPh: "Search football, padel, chess…",
  location: "Cairo / Obour",
  createEvent: "Create Event",
  verified: "Verified",
  langLabel: "العربية",

  liveBadge: "Happening now in Obour",
  welcome: "Welcome back,",
  welcomeName: "Kareem",
  welcomeSub:
    "Your neighbors are meeting up all around Obour this week. Grab a spot before they fill up.",
  searchCta: "Search",
  today: "Today",
  tomorrow: "Tomorrow",
  weekend: "This Weekend",
  pickDate: "Pick a date",
  statEvents: "events this week",
  statGoing: "neighbors going",
  statLeft: "spots left today",

  hlLabel: "Tonight's highlight",
  hlTitle: "7-a-side Friendly Match",
  hlVenue: "Obour Sporting Club · Pitch 4",
  hlTime: "Tonight · 9:00 PM",
  hlSpots: "3 spots left",
  hlCta: "Join now",
  hlGoing: "going",

  categories: {
    all: "All Activities",
    football: "Football",
    padel: "Padel & Tennis",
    running: "Running Club",
    chess: "Chess & Board Games",
    books: "Book Discussion",
    cycling: "Cycling",
  },

  partTitle: "Your Active Participations",
  partBadge: "2 scheduled",
  manageAll: "Manage all",

  card1Status: "Confirmed · gate pass ready",
  card1VenueChip: "Obour Sporting Club",
  card1Time: "Tonight · 9:00 PM",
  card1Title: "7-a-side Friendly Match & Tactics",
  card1Venue: "Pitch 4, Obour Sporting Club, District 2",
  card1Countdown: "Starts in 3h",
  stepRequested: "Requested",
  stepAccepted: "Accepted",
  stepGathering: "Gathering",
  card1Host: "Youssef Mansour",
  hostRole: "Host",
  map: "Map",
  openChat: "Open Event Chat",

  card2Status: "Request Pending",
  card2VenueChip: "Golf City Mall",
  card2Time: "Thursday · 7:30 PM",
  card2Title: "Community Civic Tech & Urban Design Circle",
  card2Venue: "Caribou Coffee terrace, Zone B",
  card2Note: "The organizer verifies all first-time RSVPs within 4 hours.",
  card2Spot: "#6 in queue",
  card2Host: "Nourhan Samir",
  organizerRole: "Organizer · 4.9 ★",
  cancel: "Cancel",
  viewDetails: "View Details",

  discoverTitle: "Happening Near You in Obour",
  discoverLive: "LIVE",
  discoverSub: "Fresh meetups from your neighborhood — updated 5 minutes ago",
  filters: "Filters",
  viewMap: "Map view",
  members: "members",
  almostFull: "Almost full",
  fillingFast: "Filling fast",
  newBadge: "New",
  popular: "Popular",
  viewEvent: "View Event",

  gatherChip: "Takes 2 minutes",
  gatherTitle: "Got a passion? Gather your neighbors",
  gatherBody:
    "A match, a running trail, or a skill worth sharing — publish your own meetup and decide exactly who joins.",
  gatherCheck1: "Screen attendee profiles before accepting",
  gatherCheck2: "Automatic headcount tracking",
  gatherCheck3: "Members-only event chat",
  gatherCta: "Create an Event — it's free",

  trustTitle: "A safer community, by design",
  trustBody:
    "Identity documents are required to help maintain a safer community. Report and block tools are always one tap away.",
  trustMembers: "1,200+ verified neighbors",
  report: "Report an Issue",
  safety: "Safety Guidelines",

  footerTag: "Built for neighbors, by neighbors",
  rights: "© 2025 Community Platform",
  trustCenter: "Trust Center",

  toastTitle: "Let's go! 🎉",
  toastMsg: "Event details opened — request your seat before spots fill up.",
};

export type Dict = typeof en;

const ar: Dict = {
  brand: "منصة المجتمع",
  navHome: "الرئيسية",
  navNearby: "فعاليات قريبة",
  navMy: "فعالياتي",
  navChat: "المحادثات",
  searchPh: "ابحث عن كرة قدم، بادل، شطرنج…",
  location: "القاهرة / العبور",
  createEvent: "إنشاء فعالية",
  verified: "موثّق",
  langLabel: "English",

  liveBadge: "تجمعات جارية الآن في العبور",
  welcome: "مرحباً بعودتك،",
  welcomeName: "كريم",
  welcomeSub:
    "جيرانك بيتجمعوا في كل حتة حول العبور الأسبوع ده. احجز مكانك قبل ما الأماكن تخلص.",
  searchCta: "ابحث",
  today: "اليوم",
  tomorrow: "غداً",
  weekend: "نهاية الأسبوع",
  pickDate: "اختر تاريخاً",
  statEvents: "فعالية هذا الأسبوع",
  statGoing: "جار يشارك",
  statLeft: "مكان متاح اليوم",

  hlLabel: "أبرز فعالية الليلة",
  hlTitle: "مباراة ودية ٧ ضد ٧",
  hlVenue: "نادي العبور الرياضي · ملعب ٤",
  hlTime: "الليلة · ٩:٠٠ م",
  hlSpots: "تبقّى ٣ أماكن",
  hlCta: "انضم الآن",
  hlGoing: "شارك",

  categories: {
    all: "كل الأنشطة",
    football: "كرة القدم",
    padel: "بادل وتنس",
    running: "نادي الجري",
    chess: "شطرنج وألعاب",
    books: "نادي الكتاب",
    cycling: "الدراجات",
  },

  partTitle: "مشاركاتك النشطة",
  partBadge: "٢ مجدولة",
  manageAll: "إدارة الكل",

  card1Status: "مؤكّد · بطاقة الدخول جاهزة",
  card1VenueChip: "نادي العبور الرياضي",
  card1Time: "الليلة · ٩:٠٠ م",
  card1Title: "مباراة ودية ٧ ضد ٧ وخطط تكتيكية",
  card1Venue: "ملعب ٤، نادي العبور الرياضي، الحي الثاني",
  card1Countdown: "تبدأ بعد ٣ ساعات",
  stepRequested: "تم الطلب",
  stepAccepted: "تم القبول",
  stepGathering: "نقطة التجمع",
  card1Host: "يوسف منصور",
  hostRole: "المضيف",
  map: "خريطة",
  openChat: "افتح محادثة الفعالية",

  card2Status: "الطلب قيد الانتظار",
  card2VenueChip: "مول سيتي جولف",
  card2Time: "الخميس · ٧:٣٠ م",
  card2Title: "حلقة التقنية المدنية والتصميم الحضري",
  card2Venue: "شرفة كاريبو كوفي، المنطقة ب",
  card2Note: "يتحقق المنظّم من طلبات الحضور لأول مرة خلال ٤ ساعات.",
  card2Spot: "رقم ٦ في قائمة الانتظار",
  card2Host: "نورهان سمير",
  organizerRole: "منظّمة · ٤.٩ ★",
  cancel: "إلغاء",
  viewDetails: "عرض التفاصيل",

  discoverTitle: "يحدث قربك في العبور",
  discoverLive: "مباشر",
  discoverSub: "تجمعات جديدة من حيّك — آخر تحديث قبل ٥ دقائق",
  filters: "تصفية",
  viewMap: "عرض الخريطة",
  members: "عضو",
  almostFull: "امتلاء قريب",
  fillingFast: "الأماكن تسرع",
  newBadge: "جديد",
  popular: "رائج",
  viewEvent: "عرض الفعالية",

  gatherChip: "أقل من دقيقتين",
  gatherTitle: "عندك شغف؟ اجمع جيرانك",
  gatherBody:
    "مباراة، مسار جري، أو مهارة تستاهل المشاركة — انشر تجمعك بنفسك وحدّد بنفسك مين ينضم.",
  gatherCheck1: "راجع ملفات الحضور قبل القبول",
  gatherCheck2: "عدّ تلقائي لعدد الأعضاء",
  gatherCheck3: "محادثة خاصة بأعضاء الفعالية",
  gatherCta: "أنشئ فعالية — مجاناً",

  trustTitle: "مجتمع أكثر أماناً بالتصميم",
  trustBody:
    "مستندات الهوية مطلوبة للمساعدة في الحفاظ على مجتمع أكثر أماناً. أدوات الإبلاغ والحظر متاحة دائماً بلمسة واحدة.",
  trustMembers: "+١٢٠٠ جار موثّق",
  report: "الإبلاغ عن مشكلة",
  safety: "إرشادات السلامة",

  footerTag: "من الجيران، للجيران",
  rights: "© ٢٠٢٥ منصة المجتمع",
  trustCenter: "مركز الثقة",

  toastTitle: "يلا بينا! 🎉",
  toastMsg: "تم فتح تفاصيل الفعالية — اطلب مكانك قبل ما الأماكن تخلص.",
};

export const dicts: Record<Locale, Dict> = { en, ar };

export const categories: CategoryItem[] = [
  { id: "all", emoji: "✨", count: 24 },
  { id: "football", emoji: "⚽", count: 8 },
  { id: "padel", emoji: "🎾", count: 5 },
  { id: "running", emoji: "🏃", count: 4 },
  { id: "chess", emoji: "♟️", count: 3 },
  { id: "books", emoji: "📚", count: 2 },
  { id: "cycling", emoji: "🚴", count: 2 },
];

export const events: EventItem[] = [
  {
    id: "football",
    img: "/events/football.png",
    emoji: "⚽",
    joined: 7,
    total: 10,
    hostInitials: "AS",
    urgency: "almostFull",
    copy: {
      category: "Football",
      title: "Football — Obour",
      venue: "Al Ahly Club Playground",
      date: "Today · 8:00 PM",
      price: "80 EGP",
      host: "Ahmed S.",
    },
  },
  {
    id: "padel",
    img: "/events/padel.png",
    emoji: "🎾",
    joined: 3,
    total: 4,
    hostInitials: "MA",
    urgency: "almostFull",
    copy: {
      category: "Padel",
      title: "Friendly Doubles — Intermediate",
      venue: "Smash Padel Academy",
      date: "Tomorrow · 6:30 PM",
      price: "120 EGP",
      host: "Mohamed Adel",
    },
  },
  {
    id: "running",
    img: "/events/running.png",
    emoji: "🏃",
    joined: 14,
    total: 20,
    hostInitials: "LT",
    urgency: "popular",
    copy: {
      category: "Running Club",
      title: "Sunrise 5K Neighborhood Jog",
      venue: "City Promenade Park Gate 2",
      date: "Friday · 6:30 AM",
      price: "Free",
      host: "Layla Tarek",
    },
  },
  {
    id: "chess",
    img: "/events/chess.png",
    emoji: "♟️",
    joined: 6,
    total: 8,
    hostInitials: "KN",
    urgency: "new",
    copy: {
      category: "Chess",
      title: "Casual Chess & Coffee Evening",
      venue: "Espresso Lab, Golf City Mall",
      date: "Saturday · 7:00 PM",
      price: "Free (order a drink)",
      host: "Karim Nabil",
    },
  },
  {
    id: "cycling",
    img: "/events/cycling.png",
    emoji: "🚴",
    joined: 9,
    total: 12,
    hostInitials: "SH",
    urgency: "fillingFast",
    copy: {
      category: "Cycling",
      title: "Sunset City Ride — 15K",
      venue: "Obour Corniche Loop",
      date: "Sunday · 5:00 PM",
      price: "40 EGP",
      host: "Salma H.",
    },
  },
];

export const eventCopyAr: Record<string, EventItem["copy"]> = {
  football: {
    category: "كرة القدم",
    title: "كرة القدم — العبور",
    venue: "ملعب نادي الأهلي",
    date: "اليوم · ٨:٠٠ م",
    price: "٨٠ ج.م",
    host: "أحمد س.",
  },
  padel: {
    category: "بادل",
    title: "مباراة بادل زوجية — مستوى متوسط",
    venue: "أكاديمية سماش بادل",
    date: "غداً · ٦:٣٠ م",
    price: "١٢٠ ج.م",
    host: "محمد عادل",
  },
  running: {
    category: "نادي الجري",
    title: "جري ٥ كم عند الشروق",
    venue: "حديقة الممشى — بوابة ٢",
    date: "الجمعة · ٦:٣٠ ص",
    price: "مجاني",
    host: "ليلى طارق",
  },
  chess: {
    category: "شطرنج",
    title: "سهرة شطرنج وقهوة",
    venue: "إسبريسو لاب، مول سيتي جولف",
    date: "السبت · ٧:٠٠ م",
    price: "مجاني (اطلب مشروب)",
    host: "كريم نبيل",
  },
  cycling: {
    category: "دراجات",
    title: "جولة غروب بالمدينة — ١٥ كم",
    venue: "حلبة كورنيش العبور",
    date: "الأحد · ٥:٠٠ م",
    price: "٤٠ ج.م",
    host: "سلمى ح.",
  },
};

export function getEvents(locale: Locale): EventItem[] {
  if (locale === "en") return events;
  return events.map((e) => ({ ...e, copy: eventCopyAr[e.id] ?? e.copy }));
}
