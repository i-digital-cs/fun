"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Ambient } from "@/components/community/ambient";
import { Navbar } from "@/components/community/navbar";
import { Hero } from "@/components/community/hero";
import { Participations } from "@/components/community/participations";
import { Discover } from "@/components/community/discover";
import { Footer, Toast, Trust } from "@/components/community/closing";
import { dicts, type Locale } from "@/lib/community/content";

export default function Home() {
  const [locale, setLocale] = useState<Locale>("en");
  const [activeCategory, setActiveCategory] = useState("all");
  const [activeDate, setActiveDate] = useState("today");
  const [toastOpen, setToastOpen] = useState(false);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Restore locale preference (deferred to avoid sync setState in effect)
  useEffect(() => {
    const raf = requestAnimationFrame(() => {
      const stored = window.localStorage.getItem("ui_locale");
      if (stored === "ar" || stored === "en") setLocale(stored);
    });
    return () => cancelAnimationFrame(raf);
  }, []);

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";
    window.localStorage.setItem("ui_locale", locale);
  }, [locale]);

  // Announce category selection via toast for demo purposes
  const handleViewEvent = useCallback(() => {
    setToastOpen(true);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastOpen(false), 3600);
  }, []);

  useEffect(() => {
    return () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    };
  }, []);

  const t = dicts[locale];
  const toggleLocale = useCallback(
    () => setLocale((v) => (v === "en" ? "ar" : "en")),
    []
  );

  return (
    <div className="flex min-h-screen flex-col">
      <Ambient />
      <Navbar t={t} locale={locale} onToggleLocale={toggleLocale} />

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 pb-4 sm:px-6">
        <Hero
          t={t}
          activeCategory={activeCategory}
          onSelectCategory={setActiveCategory}
          activeDate={activeDate}
          onSelectDate={setActiveDate}
        />
        <Participations t={t} />
        <Discover t={t} locale={locale} onViewEvent={handleViewEvent} />
        <Trust t={t} />
      </main>

      <Footer t={t} locale={locale} onToggleLocale={toggleLocale} />
      <Toast open={toastOpen} title={t.toastTitle} message={t.toastMsg} />
    </div>
  );
}
