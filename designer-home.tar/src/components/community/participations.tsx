"use client";

import { motion } from "framer-motion";
import {
  ArrowRight,
  CalendarClock,
  CheckCircle2,
  ChevronRight,
  Hourglass,
  Map,
  MapPin,
  MessageCircle,
  ShieldCheck,
  Star,
  Timer,
} from "lucide-react";
import type { Dict } from "@/lib/community/content";

function Stepper({ t }: { t: Dict }) {
  const steps = [
    { label: t.stepRequested, state: "done" as const },
    { label: t.stepAccepted, state: "done" as const },
    { label: t.stepGathering, state: "next" as const },
  ];
  return (
    <div className="flex items-center gap-2">
      {steps.map((s, i) => (
        <div key={s.label} className="flex flex-1 items-center gap-2">
          <div className="flex items-center gap-1.5">
            <span
              className={
                s.state === "done"
                  ? "flex h-7 w-7 items-center justify-center rounded-full bg-emerald-500 text-white shadow-md shadow-emerald-500/30"
                  : "flex h-7 w-7 items-center justify-center rounded-full bg-slate-100 text-slate-400 ring-4 ring-slate-50"
              }
            >
              {s.state === "done" ? (
                <CheckCircle2 className="h-4 w-4" />
              ) : (
                <MapPin className="h-3.5 w-3.5" />
              )}
            </span>
            <span
              className={
                s.state === "done"
                  ? "text-xs font-bold text-emerald-700"
                  : "text-xs font-semibold text-slate-400"
              }
            >
              {s.label}
            </span>
          </div>
          {i < steps.length - 1 && (
            <span className="h-0.5 flex-1 rounded-full bg-gradient-to-r from-emerald-300 to-slate-200" />
          )}
        </div>
      ))}
    </div>
  );
}

export function Participations({ t }: { t: Dict }) {
  return (
    <section className="mt-10">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-60px" }}
        transition={{ duration: 0.5 }}
        className="mb-4 flex flex-wrap items-center justify-between gap-3"
      >
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-600/25">
            <CalendarClock className="h-5 w-5" />
          </span>
          <h2 className="text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">
            {t.partTitle}
          </h2>
          <span className="rounded-full bg-indigo-100 px-2.5 py-1 text-[11px] font-bold text-indigo-700">
            {t.partBadge}
          </span>
        </div>
        <a
          href="#"
          className="group flex items-center gap-1 text-sm font-bold text-indigo-600 transition hover:text-indigo-800"
        >
          {t.manageAll}
          <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 rtl:rotate-180 rtl:group-hover:-translate-x-0.5" />
        </a>
      </motion.div>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* Card 1 — Confirmed */}
        <motion.article
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5 }}
          className="group relative flex flex-col gap-4 overflow-hidden rounded-3xl border border-slate-200/70 bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-indigo-600/10"
        >
          <span className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-indigo-500 via-violet-500 to-orange-400" />

          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1.5 text-[11px] font-bold text-emerald-700">
              <ShieldCheck className="h-3.5 w-3.5" />
              {t.card1Status}
            </span>
            <span className="flex items-center gap-2">
              <span className="flex items-center gap-1.5 rounded-full bg-slate-900 px-3 py-1.5 text-[11px] font-bold text-white">
                <Timer className="h-3.5 w-3.5 text-amber-300" />
                {t.card1Countdown}
              </span>
              <span className="text-xs font-semibold text-slate-400">{t.card1Time}</span>
            </span>
          </div>

          <div>
            <h3 className="text-lg font-extrabold leading-snug tracking-tight text-slate-900 transition group-hover:text-indigo-700">
              {t.card1Title}
            </h3>
            <p className="mt-1 flex items-center gap-1.5 text-sm text-slate-500">
              <MapPin className="h-4 w-4 shrink-0 text-indigo-400" />
              {t.card1Venue}
            </p>
          </div>

          <Stepper t={t} />

          <div className="mt-auto flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
            <div className="flex items-center gap-2.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-xs font-black text-white shadow-md shadow-indigo-500/25">
                YM
              </span>
              <div className="leading-tight">
                <p className="text-sm font-bold text-slate-800">{t.card1Host}</p>
                <p className="text-[11px] font-medium text-slate-400">{t.hostRole}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                className="flex items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-bold text-slate-600 transition hover:border-indigo-300 hover:text-indigo-700"
              >
                <Map className="h-3.5 w-3.5" />
                {t.map}
              </button>
              <button
                type="button"
                className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-2.5 text-xs font-bold text-white shadow-lg shadow-indigo-600/25 transition hover:-translate-y-0.5 hover:shadow-xl hover:shadow-indigo-600/35 active:translate-y-0"
              >
                <MessageCircle className="h-3.5 w-3.5" />
                {t.openChat}
              </button>
            </div>
          </div>
        </motion.article>

        {/* Card 2 — Pending */}
        <motion.article
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="group relative flex flex-col gap-4 overflow-hidden rounded-3xl border border-slate-200/70 bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-2xl hover:shadow-amber-500/10"
        >
          <span className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-amber-400 via-orange-400 to-rose-400" />

          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="flex items-center gap-1.5 rounded-full border border-amber-200 bg-amber-50 px-3 py-1.5 text-[11px] font-bold text-amber-700">
              <Hourglass className="h-3.5 w-3.5" />
              {t.card2Status}
            </span>
            <span className="text-xs font-semibold text-slate-400">{t.card2Time}</span>
          </div>

          <div>
            <h3 className="text-lg font-extrabold leading-snug tracking-tight text-slate-900 transition group-hover:text-indigo-700">
              {t.card2Title}
            </h3>
            <p className="mt-1 flex items-center gap-1.5 text-sm text-slate-500">
              <MapPin className="h-4 w-4 shrink-0 text-indigo-400" />
              {t.card2Venue}
            </p>
          </div>

          <div className="flex items-center justify-between gap-3 rounded-2xl border border-amber-200/70 bg-amber-50/70 px-4 py-3">
            <p className="text-xs font-medium leading-relaxed text-amber-800">{t.card2Note}</p>
            <span className="shrink-0 rounded-full bg-white px-2.5 py-1 text-[11px] font-black text-amber-600 shadow-sm">
              {t.card2Spot}
            </span>
          </div>

          <div className="mt-auto flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4">
            <div className="flex items-center gap-2.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-rose-400 to-orange-400 text-xs font-black text-white shadow-md shadow-orange-500/25">
                NS
              </span>
              <div className="leading-tight">
                <p className="text-sm font-bold text-slate-800">{t.card2Host}</p>
                <p className="flex items-center gap-1 text-[11px] font-medium text-slate-400">
                  <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                  {t.organizerRole}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                className="rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-xs font-bold text-slate-600 transition hover:border-rose-300 hover:text-rose-600"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                className="flex items-center gap-1.5 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-bold text-white shadow-lg transition hover:-translate-y-0.5 hover:bg-slate-800 active:translate-y-0"
              >
                {t.viewDetails}
                <ArrowRight className="h-3.5 w-3.5 rtl:rotate-180" />
              </button>
            </div>
          </div>
        </motion.article>
      </div>
    </section>
  );
}
