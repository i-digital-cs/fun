"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  BookOpen,
  Flag,
  Globe,
  Heart,
  PartyPopper,
  ShieldCheck,
  Users,
} from "lucide-react";
import type { Dict, Locale } from "@/lib/community/content";

export function Trust({ t }: { t: Dict }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5 }}
      className="relative mt-12 overflow-hidden rounded-[2rem] bg-gradient-to-r from-emerald-600 via-emerald-600 to-teal-600 p-6 text-white shadow-2xl shadow-emerald-600/25 sm:p-8"
    >
      <div aria-hidden className="absolute inset-0">
        <div className="absolute -end-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <ShieldCheck
          className="animate-float absolute end-8 top-1/2 hidden h-40 w-40 -translate-y-1/2 text-white/10 lg:block"
          aria-hidden
        />
        <div className="bg-dots absolute inset-0 opacity-40" />
      </div>

      <div className="relative flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex items-start gap-4">
          <span className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white/15 backdrop-blur">
            <ShieldCheck className="h-7 w-7" />
          </span>
          <div>
            <div className="flex flex-wrap items-center gap-2.5">
              <h2 className="text-lg font-extrabold tracking-tight sm:text-xl">{t.trustTitle}</h2>
              <span className="rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold backdrop-blur">
                {t.trustMembers}
              </span>
            </div>
            <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-emerald-50/90">
              {t.trustBody}
            </p>
          </div>
        </div>
        <div className="flex shrink-0 flex-wrap gap-2.5">
          <button
            type="button"
            className="flex items-center gap-1.5 rounded-xl border border-white/25 bg-white/10 px-4 py-2.5 text-xs font-bold backdrop-blur transition hover:bg-white/20"
          >
            <Flag className="h-3.5 w-3.5" />
            {t.report}
          </button>
          <button
            type="button"
            className="flex items-center gap-1.5 rounded-xl bg-white px-4 py-2.5 text-xs font-extrabold text-emerald-700 shadow-lg transition hover:scale-[1.03] active:scale-95"
          >
            <BookOpen className="h-3.5 w-3.5" />
            {t.safety}
          </button>
        </div>
      </div>
    </motion.section>
  );
}

export function Footer({
  t,
  locale,
  onToggleLocale,
}: {
  t: Dict;
  locale: Locale;
  onToggleLocale: () => void;
}) {
  return (
    <footer className="mt-14 border-t border-slate-200/70 bg-white/60 backdrop-blur">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 py-6 sm:flex-row sm:px-6">
        <div className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-600 to-violet-600 text-white">
            <Users className="h-4 w-4" />
          </span>
          <span className="text-sm font-extrabold tracking-tight text-slate-900">{t.brand}</span>
          <span className="hidden items-center gap-1 text-xs font-medium text-slate-400 sm:flex">
            · <Heart className="h-3 w-3 fill-rose-400 text-rose-400" /> {t.footerTag}
          </span>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3 text-xs font-semibold text-slate-500">
          <a href="#" className="flex items-center gap-1 transition hover:text-emerald-600">
            <ShieldCheck className="h-3.5 w-3.5" />
            {t.safety}
          </a>
          <a href="#" className="flex items-center gap-1 transition hover:text-indigo-600">
            <Flag className="h-3.5 w-3.5" />
            {t.trustCenter}
          </a>
          <span className="text-slate-300">|</span>
          <button
            type="button"
            onClick={onToggleLocale}
            className="flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 py-1.5 transition hover:border-indigo-300 hover:text-indigo-700"
            aria-label="Switch language"
          >
            <Globe className="h-3.5 w-3.5" />
            {locale === "en" ? "العربية" : "English"}
          </button>
        </div>
      </div>
      <p className="border-t border-slate-100 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 text-center text-[11px] text-slate-400">
        {t.rights}
      </p>
    </footer>
  );
}

export function Toast({
  open,
  title,
  message,
}: {
  open: boolean;
  title: string;
  message: string;
}) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.97 }}
          transition={{ type: "spring", stiffness: 400, damping: 28 }}
          role="status"
          aria-live="polite"
          className="fixed bottom-6 end-6 z-[100] flex w-[calc(100vw-3rem)] max-w-sm items-start gap-3 rounded-2xl bg-slate-900 p-4 text-white shadow-2xl"
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-amber-500">
            <PartyPopper className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-extrabold">{title}</p>
            <p className="mt-0.5 text-xs leading-relaxed text-slate-300">{message}</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
