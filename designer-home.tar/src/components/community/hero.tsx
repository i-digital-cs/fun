"use client";

import { motion } from "framer-motion";
import { CalendarDays, Clock3, Flame, MapPin, Search, Sparkles, Users } from "lucide-react";
import { categories, type Dict } from "@/lib/community/content";

interface HeroProps {
  t: Dict;
  activeCategory: string;
  onSelectCategory: (id: string) => void;
  activeDate: string;
  onSelectDate: (id: string) => void;
}

const fadeUp = {
  initial: { opacity: 0, y: 24 },
  animate: { opacity: 1, y: 0 },
};

export function Hero({ t, activeCategory, onSelectCategory, activeDate, onSelectDate }: HeroProps) {
  const dateChips = [
    { id: "today", label: t.today },
    { id: "tomorrow", label: t.tomorrow },
    { id: "weekend", label: t.weekend },
    { id: "pick", label: t.pickDate },
  ];

  const stats = [
    { value: "24", label: t.statEvents },
    { value: "128", label: t.statGoing },
    { value: "9", label: t.statLeft },
  ];

  return (
    <section className="pt-6 sm:pt-8">
      <motion.div
        {...fadeUp}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="relative overflow-hidden rounded-[2rem] bg-gradient-to-br from-indigo-700 via-violet-700 to-indigo-900 shadow-2xl shadow-indigo-600/25"
      >
        {/* decorative layers */}
        <div aria-hidden className="absolute inset-0">
          <div className="absolute -top-32 -end-24 h-96 w-96 rounded-full bg-orange-400/25 blur-3xl" />
          <div className="absolute -bottom-40 -start-20 h-96 w-96 rounded-full bg-fuchsia-500/20 blur-3xl" />
          <div className="bg-dots absolute inset-0 opacity-60" />
          {/* floating emoji stickers */}
          <span
            className="animate-float absolute end-[26rem] top-10 hidden text-5xl drop-shadow-xl xl:block"
            style={{ ["--float-rot" as string]: "12deg" }}
          >
            ⚽
          </span>
          <span
            className="animate-float absolute end-8 bottom-40 hidden text-4xl opacity-90 drop-shadow-xl lg:block"
            style={{ ["--float-rot" as string]: "-10deg", animationDelay: "-2s" }}
          >
            ♟️
          </span>
          <span
            className="animate-float absolute start-[30rem] top-8 hidden text-4xl opacity-80 drop-shadow-xl lg:block"
            style={{ ["--float-rot" as string]: "8deg", animationDelay: "-4s" }}
          >
            🎾
          </span>
        </div>

        <div className="relative grid gap-8 p-6 sm:p-10 lg:grid-cols-[1fr_340px] lg:p-12">
          {/* Left column */}
          <div className="flex flex-col gap-6">
            <div className="flex flex-wrap items-center gap-3">
              <span className="flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3.5 py-1.5 text-xs font-semibold text-white backdrop-blur">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
                </span>
                {t.liveBadge}
              </span>
            </div>

            <div>
              <h1 className="text-3xl font-extrabold leading-tight tracking-tight text-white sm:text-4xl lg:text-[2.75rem]">
                {t.welcome}{" "}
                <span className="bg-gradient-to-r from-amber-300 to-orange-400 bg-clip-text text-transparent">
                  {t.welcomeName}
                </span>{" "}
                <span className="inline-block origin-bottom-right hover:rotate-12">👋</span>
              </h1>
              <p className="mt-3 max-w-xl text-sm leading-relaxed text-indigo-100/90 sm:text-base">
                {t.welcomeSub}
              </p>
            </div>

            {/* Search */}
            <div className="flex max-w-xl items-center gap-2 rounded-2xl border border-white/20 bg-white/10 p-2 backdrop-blur-xl transition focus-within:border-white/40 focus-within:bg-white/15">
              <Search className="ms-2 h-5 w-5 shrink-0 text-indigo-200" />
              <input
                type="search"
                placeholder={t.searchPh}
                aria-label={t.searchPh}
                className="min-w-0 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-indigo-200/70"
              />
              <button
                type="button"
                className="flex h-10 shrink-0 items-center gap-1.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 px-4 text-sm font-bold text-white shadow-lg shadow-orange-900/30 transition hover:brightness-110 active:scale-95"
              >
                <Sparkles className="h-4 w-4" />
                <span className="hidden sm:inline">{t.searchCta}</span>
              </button>
            </div>

            {/* Date chips */}
            <div className="flex flex-wrap gap-2" role="tablist" aria-label={t.pickDate}>
              {dateChips.map((c) => {
                const active = activeDate === c.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    onClick={() => onSelectDate(c.id)}
                    className={
                      active
                        ? "flex items-center gap-1.5 rounded-full bg-white px-4 py-2 text-xs font-bold text-indigo-700 shadow-lg"
                        : "flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-xs font-semibold text-indigo-50 backdrop-blur transition hover:-translate-y-0.5 hover:bg-white/20"
                    }
                  >
                    {c.id === "pick" ? (
                      <CalendarDays className="h-3.5 w-3.5" />
                    ) : (
                      <Clock3 className="h-3.5 w-3.5" />
                    )}
                    {c.label}
                  </button>
                );
              })}
            </div>

            {/* Stats */}
            <div className="grid max-w-xl grid-cols-3 gap-3">
              {stats.map((s) => (
                <div
                  key={s.label}
                  className="rounded-2xl border border-white/15 bg-white/10 px-4 py-3 backdrop-blur transition hover:border-white/30 hover:bg-white/15"
                >
                  <div className="text-2xl font-extrabold text-white">{s.value}</div>
                  <div className="mt-0.5 text-[11px] font-medium leading-tight text-indigo-200">
                    {s.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right column — tonight's highlight */}
          <motion.aside
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.55, delay: 0.15, ease: "easeOut" }}
            className="flex flex-col gap-4 rounded-3xl border border-white/20 bg-white/10 p-5 backdrop-blur-xl"
          >
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-300">
                <Flame className="h-4 w-4" />
                {t.hlLabel}
              </span>
              <span className="rounded-full bg-orange-500 px-2.5 py-1 text-[10px] font-black text-white shadow-lg shadow-orange-900/40">
                {t.hlSpots}
              </span>
            </div>

            <div className="relative overflow-hidden rounded-2xl">
              <img
                src="/events/football.png"
                alt={t.hlTitle}
                className="h-36 w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-indigo-950/80 to-transparent" />
              <div className="absolute bottom-3 start-3 end-3">
                <p className="text-base font-extrabold leading-snug text-white">{t.hlTitle}</p>
                <p className="mt-0.5 flex items-center gap-1 text-[11px] font-medium text-indigo-200">
                  <MapPin className="h-3 w-3" /> {t.hlVenue}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-indigo-100">
              <span className="flex items-center gap-1.5 font-semibold">
                <Clock3 className="h-3.5 w-3.5" /> {t.hlTime}
              </span>
              <span className="flex -space-x-2">
                {["YM", "AS", "MA"].map((i, idx) => (
                  <span
                    key={i}
                    className="flex h-6 w-6 items-center justify-center rounded-full border-2 border-indigo-800 bg-gradient-to-br from-indigo-400 to-violet-500 text-[9px] font-bold text-white"
                    style={{ zIndex: 3 - idx }}
                  >
                    {i}
                  </span>
                ))}
                <span className="flex h-6 items-center rounded-full border-2 border-indigo-800 bg-white/20 px-1.5 text-[9px] font-bold text-white">
                  +4
                </span>
              </span>
            </div>

            <button
              type="button"
              className="mt-auto flex w-full items-center justify-center gap-2 rounded-xl bg-white py-3 text-sm font-extrabold text-indigo-700 shadow-xl transition hover:scale-[1.02] hover:bg-indigo-50 active:scale-95"
            >
              <Users className="h-4 w-4" />
              {t.hlCta}
            </button>
          </motion.aside>
        </div>
      </motion.div>

      {/* Category rail */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2, ease: "easeOut" }}
        className="fancy-scroll mt-6 flex gap-2.5 overflow-x-auto pb-2"
        role="toolbar"
        aria-label={t.categories.all}
      >
        {categories.map((c) => {
          const active = activeCategory === c.id;
          return (
            <button
              key={c.id}
              type="button"
              onClick={() => onSelectCategory(c.id)}
              aria-pressed={active}
              className={
                active
                  ? "flex shrink-0 items-center gap-2 rounded-full bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-indigo-600/30 transition-all"
                  : "flex shrink-0 items-center gap-2 rounded-full border border-slate-200 bg-white/80 px-4 py-2.5 text-sm font-semibold text-slate-600 backdrop-blur transition-all hover:-translate-y-0.5 hover:border-indigo-300 hover:text-indigo-700 hover:shadow-md"
              }
            >
              <span className="text-base leading-none">{c.emoji}</span>
              {t.categories[c.id as keyof typeof t.categories]}
              <span
                className={
                  active
                    ? "rounded-full bg-white/25 px-1.5 py-0.5 text-[10px] font-bold text-white"
                    : "rounded-full bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-500"
                }
              >
                {c.count}
              </span>
            </button>
          );
        })}
      </motion.div>
    </section>
  );
}
