"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import {
  ArrowRight,
  CalendarClock,
  Check,
  Flame,
  Map as MapIcon,
  MapPin,
  Plus,
  SlidersHorizontal,
  Sparkles,
  TrendingUp,
  Zap,
} from "lucide-react";
import { getEvents, type Dict, type Locale, type Urgency } from "@/lib/community/content";

const urgencyStyle: Record<Urgency, { chip: string; icon: typeof Flame; label: (d: Dict) => string }> = {
  almostFull: { chip: "text-orange-600", icon: Flame, label: (d) => d.almostFull },
  fillingFast: { chip: "text-rose-600", icon: Zap, label: (d) => d.fillingFast },
  new: { chip: "text-emerald-600", icon: Sparkles, label: (d) => d.newBadge },
  popular: { chip: "text-violet-600", icon: TrendingUp, label: (d) => d.popular },
};

interface DiscoverProps {
  t: Dict;
  locale: Locale;
  onViewEvent: (title: string) => void;
}

export function Discover({ t, locale, onViewEvent }: DiscoverProps) {
  const items = getEvents(locale);

  return (
    <section className="mt-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-60px" }}
        transition={{ duration: 0.5 }}
        className="mb-5 flex flex-wrap items-end justify-between gap-3"
      >
        <div>
          <h2 className="flex items-center gap-2.5 text-xl font-extrabold tracking-tight text-slate-900 sm:text-2xl">
            {t.discoverTitle}
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-orange-400 opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-orange-500" />
            </span>
          </h2>
          <p className="mt-1 text-sm text-slate-500">{t.discoverSub}</p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            className="flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/80 px-4 py-2 text-xs font-bold text-slate-600 backdrop-blur transition hover:border-indigo-300 hover:text-indigo-700"
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
            {t.filters}
          </button>
          <button
            type="button"
            className="flex items-center gap-1.5 rounded-full border border-slate-200 bg-white/80 px-4 py-2 text-xs font-bold text-slate-600 backdrop-blur transition hover:border-indigo-300 hover:text-indigo-700"
          >
            <MapIcon className="h-3.5 w-3.5" />
            {t.viewMap}
          </button>
        </div>
      </motion.div>

      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {items.map((e, i) => {
          const pct = Math.round((e.joined / e.total) * 100);
          const urgent = pct >= 80;
          const u = urgencyStyle[e.urgency];
          const UrgencyIcon = u.icon;
          const isFree = e.copy.price.toLowerCase().startsWith("free") || e.copy.price.includes("مجاني");

          return (
            <motion.article
              key={e.id}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
              className="group relative flex flex-col overflow-hidden rounded-3xl border border-slate-200/70 bg-white shadow-sm transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-indigo-600/10"
            >
              {/* Media */}
              <div className="relative h-44 overflow-hidden">
                <Image
                  src={e.img}
                  alt={e.copy.title}
                  fill
                  sizes="(max-width: 640px) 100vw, (max-width: 1280px) 50vw, 33vw"
                  priority={i < 3}
                  className="object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/50 via-transparent to-slate-950/10" />

                <span className="absolute start-3 top-3 flex items-center gap-1.5 rounded-full bg-white/90 px-3 py-1.5 text-[11px] font-bold text-slate-800 shadow-md backdrop-blur">
                  <span className="text-sm leading-none">{e.emoji}</span>
                  {e.copy.category}
                </span>
                <span
                  className={
                    isFree
                      ? "absolute end-3 top-3 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 px-3 py-1.5 text-[11px] font-black text-white shadow-lg shadow-emerald-600/40"
                      : "absolute end-3 top-3 rounded-full bg-gradient-to-r from-orange-500 to-amber-500 px-3 py-1.5 text-[11px] font-black text-white shadow-lg shadow-orange-600/40"
                  }
                >
                  {e.copy.price}
                </span>
                <span className="absolute bottom-3 start-3 flex items-center gap-1 rounded-full bg-white/95 px-2.5 py-1 text-[10px] font-black shadow backdrop-blur">
                  <UrgencyIcon className={`h-3 w-3 ${u.chip}`} />
                  <span className={u.chip}>{u.label(t)}</span>
                </span>
              </div>

              {/* Body */}
              <div className="flex flex-1 flex-col gap-3 p-5">
                <span className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-indigo-600">
                  <CalendarClock className="h-3.5 w-3.5" />
                  {e.copy.date}
                </span>
                <h3 className="text-base font-extrabold leading-snug tracking-tight text-slate-900 transition group-hover:text-indigo-700">
                  {e.copy.title}
                </h3>
                <p className="flex items-center gap-1.5 truncate text-xs text-slate-500">
                  <MapPin className="h-3.5 w-3.5 shrink-0 text-slate-400" />
                  {e.copy.venue}
                </p>

                {/* Capacity */}
                <div className="mt-1 rounded-2xl border border-slate-100 bg-slate-50/80 p-3">
                  <div className="mb-1.5 flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-500">{t.members}</span>
                    <span className="font-black text-slate-800">
                      {e.joined} / {e.total}
                    </span>
                  </div>
                  <div className="h-1.5 overflow-hidden rounded-full bg-slate-200">
                    <div
                      className={
                        urgent
                          ? "h-full rounded-full bg-gradient-to-r from-orange-500 to-amber-500"
                          : "h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500"
                      }
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <div className="mt-2.5 flex items-center justify-between">
                    <div className="flex -space-x-2 rtl:space-x-reverse">
                      {[
                        { i: e.hostInitials, bg: "linear-gradient(135deg,#6366f1,#8b5cf6)" },
                        { i: "MK", bg: "linear-gradient(135deg,#f97316,#f59e0b)" },
                        { i: "RD", bg: "linear-gradient(135deg,#10b981,#14b8a6)" },
                      ].map((m, n) => (
                        <span
                          key={n}
                          className="flex h-6 w-6 items-center justify-center rounded-full border-2 border-white text-[9px] font-bold text-white"
                          style={{ zIndex: 3 - n, backgroundImage: m.bg }}
                        >
                          {m.i}
                        </span>
                      ))}
                      {e.joined > 3 && (
                        <span className="flex h-6 items-center rounded-full border-2 border-white bg-slate-100 px-1.5 text-[9px] font-bold text-slate-500">
                          +{e.joined - 3}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] font-semibold text-slate-400">
                      {e.copy.host}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onViewEvent(e.copy.title)}
                  className="mt-auto flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 py-2.5 text-sm font-extrabold text-white shadow-lg shadow-orange-500/30 transition hover:shadow-xl hover:shadow-orange-500/45 hover:brightness-105 active:scale-[0.98]"
                >
                  {t.viewEvent}
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 rtl:rotate-180" />
                </button>
              </div>
            </motion.article>
          );
        })}

        {/* Host CTA card */}
        <motion.article
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.5, delay: 0.16 }}
          className="group relative flex flex-col overflow-hidden rounded-3xl bg-gradient-to-br from-orange-500 via-orange-500 to-amber-600 p-6 text-white shadow-xl shadow-orange-500/25 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-orange-500/40"
        >
          <div aria-hidden className="absolute inset-0">
            <div className="absolute -end-10 -top-10 h-44 w-44 rounded-full bg-white/10 blur-2xl" />
            <div className="absolute -bottom-14 -start-10 h-48 w-48 rounded-full bg-amber-300/20 blur-2xl" />
            <div className="absolute end-6 top-6 h-16 w-16 rounded-full border-2 border-dashed border-white/30 transition-transform duration-500 group-hover:rotate-45" />
          </div>

          <div className="relative flex flex-1 flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 backdrop-blur transition-transform duration-300 group-hover:scale-110">
                <Plus className="h-6 w-6" />
              </span>
              <span className="rounded-full bg-white/20 px-3 py-1 text-[10px] font-black uppercase tracking-wider backdrop-blur">
                {t.gatherChip}
              </span>
            </div>
            <h3 className="text-xl font-extrabold leading-snug tracking-tight">{t.gatherTitle}</h3>
            <p className="text-sm leading-relaxed text-orange-50/90">{t.gatherBody}</p>
            <ul className="mt-1 space-y-2">
              {[t.gatherCheck1, t.gatherCheck2, t.gatherCheck3].map((c) => (
                <li key={c} className="flex items-center gap-2 text-xs font-semibold text-orange-50">
                  <span className="flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-full bg-white/25">
                    <Check className="h-3 w-3" />
                  </span>
                  {c}
                </li>
              ))}
            </ul>
            <button
              type="button"
              className="mt-auto flex w-full items-center justify-center gap-2 rounded-xl bg-white py-3 text-sm font-extrabold text-orange-600 shadow-xl transition hover:scale-[1.02] active:scale-95"
            >
              <Sparkles className="h-4 w-4" />
              {t.gatherCta}
            </button>
          </div>
        </motion.article>
      </div>
    </section>
  );
}
