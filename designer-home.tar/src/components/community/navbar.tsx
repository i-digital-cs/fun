"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  BadgeCheck,
  Bell,
  MapPin,
  Menu,
  MessageCircle,
  Plus,
  Search,
  Users,
  X,
} from "lucide-react";
import type { Dict, Locale } from "@/lib/community/content";

interface NavbarProps {
  t: Dict;
  locale: Locale;
  onToggleLocale: () => void;
}

export function Navbar({ t, locale, onToggleLocale }: NavbarProps) {
  const [open, setOpen] = useState(false);

  const links = [
    { label: t.navHome, active: true },
    { label: t.navNearby, active: false },
    { label: t.navMy, active: false },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-white/60 bg-white/70 shadow-[0_8px_30px_rgba(15,23,42,0.05)] backdrop-blur-xl">
      <nav className="mx-auto flex min-h-16 max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
        {/* Brand */}
        <a href="#" className="group flex shrink-0 items-center gap-2.5" aria-label={t.brand}>
          <span className="relative flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-600/30 transition-transform duration-300 group-hover:scale-105 group-hover:rotate-3">
            <Users className="h-5 w-5" />
            <span className="absolute -end-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-orange-400 ring-2 ring-white" />
          </span>
          <span className="hidden flex-col leading-none sm:flex">
            <span className="text-[15px] font-extrabold tracking-tight text-slate-900">
              {t.brand}
            </span>
            <span className="mt-0.5 flex items-center gap-1 text-[10px] font-semibold uppercase tracking-widest text-indigo-500">
              <MapPin className="h-2.5 w-2.5" /> Obour
            </span>
          </span>
        </a>

        {/* Desktop links */}
        <div className="mx-2 hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <a
              key={l.label}
              href="#"
              aria-current={l.active ? "page" : undefined}
              className={
                l.active
                  ? "rounded-full bg-indigo-600/10 px-4 py-2 text-sm font-semibold text-indigo-700"
                  : "rounded-full px-4 py-2 text-sm font-medium text-slate-500 transition hover:bg-slate-100 hover:text-slate-900"
              }
            >
              {l.label}
            </a>
          ))}
          <a
            href="#"
            className="relative rounded-full px-4 py-2 text-sm font-medium text-slate-500 transition hover:bg-slate-100 hover:text-slate-900"
          >
            <span className="flex items-center gap-1.5">
              {t.navChat}
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-orange-400 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-orange-500" />
              </span>
            </span>
          </a>
        </div>

        {/* Search (xl) */}
        <div className="mx-2 hidden min-w-0 flex-1 items-center gap-2 rounded-full border border-slate-200/80 bg-slate-100/80 px-3 py-2 transition focus-within:border-indigo-300 focus-within:bg-white focus-within:ring-4 focus-within:ring-indigo-100 xl:flex">
          <span className="hidden shrink-0 items-center gap-1 rounded-full bg-indigo-100 px-2.5 py-1 text-[11px] font-bold text-indigo-700 sm:flex">
            <MapPin className="h-3 w-3" />
            {t.location}
          </span>
          <span className="h-4 w-px shrink-0 bg-slate-300" />
          <Search className="h-4 w-4 shrink-0 text-slate-400" />
          <input
            type="search"
            placeholder={t.searchPh}
            aria-label={t.searchPh}
            className="min-w-0 flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400"
          />
        </div>

        <div className="ms-auto flex items-center gap-2 lg:ms-0">
          {/* Language switch */}
          <button
            type="button"
            onClick={onToggleLocale}
            className="flex h-9 items-center gap-1.5 rounded-full border border-slate-200 bg-white px-3 text-xs font-bold text-slate-600 transition hover:border-indigo-300 hover:text-indigo-700"
            aria-label="Switch language"
          >
            <span className="text-[11px] font-black text-indigo-500">
              {locale === "en" ? "ع" : "EN"}
            </span>
            {locale === "en" ? "AR" : "EN"}
          </button>

          {/* Create Event */}
          <button
            type="button"
            className="hidden h-9 items-center gap-1.5 rounded-full bg-gradient-to-r from-orange-500 to-amber-500 px-4 text-sm font-bold text-white shadow-lg shadow-orange-500/30 transition hover:-translate-y-0.5 hover:shadow-xl hover:shadow-orange-500/40 active:translate-y-0 sm:flex"
          >
            <Plus className="h-4 w-4" />
            {t.createEvent}
          </button>

          <BadgeCheck className="hidden h-5 w-5 text-emerald-500 md:block" aria-label={t.verified} />

          <button
            type="button"
            aria-label="Notifications"
            className="relative hidden h-9 w-9 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500 transition hover:text-slate-900 md:flex"
          >
            <Bell className="h-4 w-4" />
            <span className="absolute end-2 top-2 h-2 w-2 rounded-full bg-orange-500 ring-2 ring-white" />
          </button>

          {/* Profile */}
          <button
            type="button"
            aria-label="Profile"
            className="rounded-full bg-gradient-to-tr from-indigo-600 via-violet-500 to-orange-400 p-[2px] transition hover:scale-105"
          >
            <span className="relative flex h-8 w-8 items-center justify-center rounded-full bg-white text-[13px] font-black text-indigo-700">
              K
              <span className="absolute -bottom-0.5 -end-0.5 h-3 w-3 rounded-full bg-emerald-500 ring-2 ring-white" />
            </span>
          </button>

          {/* Mobile toggle */}
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-label="Toggle menu"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-600 lg:hidden"
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
            className="overflow-hidden border-t border-slate-100 bg-white/95 backdrop-blur-xl lg:hidden"
          >
            <div className="space-y-1 px-4 py-3">
              {[...links, { label: t.navChat, active: false }].map((l) => (
                <a
                  key={l.label}
                  href="#"
                  className={`flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold ${
                    l.active ? "bg-indigo-50 text-indigo-700" : "text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  {l.active && <span className="h-1.5 w-1.5 rounded-full bg-indigo-500" />}
                  {l.label}
                </a>
              ))}
              <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2.5">
                <Search className="h-4 w-4 text-slate-400" />
                <input
                  type="search"
                  placeholder={t.searchPh}
                  aria-label={t.searchPh}
                  className="w-full bg-transparent text-sm outline-none placeholder:text-slate-400"
                />
              </div>
              <button
                type="button"
                className="flex w-full items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 px-4 py-3 text-sm font-bold text-white shadow-lg shadow-orange-500/30"
              >
                <Plus className="h-4 w-4" />
                {t.createEvent}
              </button>
              <p className="flex items-center gap-1.5 px-1 pt-1 text-[11px] font-medium text-slate-400">
                <MessageCircle className="h-3 w-3" /> {t.discoverSub}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
