"use client";

/**
 * Ambient page atmosphere — aurora gradient blobs, dot grid and noise.
 * This is what kills the "flat admin panel" feeling.
 */
export function Ambient() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {/* base tint */}
      <div className="absolute inset-0 bg-gradient-to-b from-indigo-50/60 via-slate-50 to-slate-50" />

      {/* aurora blobs */}
      <div className="animate-aurora absolute -top-48 -start-40 h-[36rem] w-[36rem] rounded-full bg-gradient-to-br from-indigo-300/45 to-violet-300/30 blur-3xl" />
      <div
        className="animate-aurora absolute top-1/4 -end-48 h-[32rem] w-[32rem] rounded-full bg-gradient-to-br from-orange-200/50 to-amber-100/30 blur-3xl"
        style={{ animationDelay: "-2.5s" }}
      />
      <div
        className="animate-aurora absolute bottom-[-12rem] start-1/3 h-[30rem] w-[30rem] rounded-full bg-gradient-to-br from-emerald-200/40 to-teal-100/25 blur-3xl"
        style={{ animationDelay: "-5s" }}
      />

      {/* dot grid, fading towards the bottom */}
      <div className="bg-dots-slate absolute inset-0 [mask-image:linear-gradient(to_bottom,black,transparent_70%)]" />

      {/* fine noise for texture */}
      <div className="bg-noise absolute inset-0 opacity-[0.35]" />
    </div>
  );
}
